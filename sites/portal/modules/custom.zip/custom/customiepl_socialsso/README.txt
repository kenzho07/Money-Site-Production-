Custom IEPL SocialSSO
==================

TODO: write some documentation.
