For using this module, please rename folder to "remove_generator".
Enable this module to remove the X-Generator option from response header and META generator tag. 
No configuration required!

This module taken from drupal.org issue que. 
Reference:
https://www.drupal.org/project/remove_generator/issues/2676164
https://www.drupal.org/u/chi


